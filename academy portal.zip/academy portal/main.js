// function to show interested students
function interest(event) {
    const getSec2 = document.querySelector(".sec2");
    const getSec3 = document.querySelector(".sec3")
}